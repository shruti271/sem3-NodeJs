/****************************************************************************** *** 
*	ITE5315 – Assignment 1 
*	I declare that this assignment is my own work in accordance with Humber Academic Policy.   *  No part of this assignment has been copied manually or electronically from any other source *  (including web sites) or distributed to other students. 
*  
*	Name: _____shrutiben italiya____ Student ID: ___N01579444____________ Date: ___05-02-2024_________________ 
* 
* 
******************************************************************************
**/  

const routes = require('./route');

const express = require('express');
// Import routes
const app = express();
const port = 8500;

app.use('/', routes)//it will direct to the route.js file

// step 3
//whenever we enter weong url it will come here
app.all("*", (req, res) => { res.status(404).send("<p style='color:red'>Error 404:<b> Page not found</b></p>"); });

app.listen(port, () => {console.log(`Example app listening on port ${port}`)});