
var jwt=require('jsonwebtoken');
var token=jwt.sign({ foo: 'bar' }, 'secret');

console.log(token);

var decoded=jwt.verify(token, 'secret')
console.log(decoded.foo);