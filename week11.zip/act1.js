const bcrypt = require('bcryptjs');
require('dotenv').config();
let hash=process.env.USER_PASS;


// bcrypt.hash("shruti", 10).then(hash=>{ //Hash the password using a Salt that was generatedusing 10 rounds
//     console.log(hash)
//     // TODO: Store the resulting "hash" value inthe DB
// }).catch(err=>{console.log(err); // Show any errors thatoccurred during the process
// })


// Pull the password "hash" value from the DB andcompare it to "myPassword123" (match)
bcrypt.compare("shruti",hash).then((result) => {
    // result === true
    if(result)
    console.log("success");
    else    
        console.log("unsuccess");
});// Pull the password "hash" value from the DB andcompare it to "myPasswordABC" (does not match)
bcrypt.compare("SHRUTIITALIYA",hash).then((result) => {
    // result === false
    if(result)
        console.log("success");
    else    
        console.log("unsuccess");
});