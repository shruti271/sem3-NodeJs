// Load environment variables from .env file
require('dotenv').config()

// Import necessary modules
const express = require('express')
const app = express()
const jwt = require('jsonwebtoken')

// Middleware to parse JSON and URL-encoded data
app.use(express.json())
app.use(express.urlencoded())

// Sample posts data
const posts = [{ username: 'admin', title: 'webAdmin' }, { username: 'nadmin', title: 'netAdmin' }]

// Route to retrieve posts
app.get('/posts', (req, res) => {
    // Respond with posts data as JSON
    res.json(posts)
})

// Route for user login
app.post('/login', (req, res) => {
    // Extract username from request body
    const username = req.body.username
    // Create user object for JWT payload
    const user = { name: username }
    // Generate access token using JWT with user object and secret key
    const accessToken = jwt.sign(user, process.env.SECRETKEY)
    // Respond with access token
    res.json({ accessToken: accessToken })
})

// Middleware function to verify JWT token
function verifyToken(req, res, next) {
    // Retrieve Authorization header from request
    const bearerHeader = req.headers['authorization']
    // Check if Authorization header is present
    if (typeof bearerHeader != 'undefined') {
        // Split Authorization header to get token
        const bearer = bearerHeader.split(' ')
        const bearerToken = bearer[1]
        // Assign token to request object
        req.token = bearerToken
        // Call next middleware
        next()
    }
}

// Protected route to retrieve posts using JWT token verification
app.get('/posts', verifyToken, (req, res) => {
    // Verify token using JWT and secret key
    jwt.verify(req.token, process.env.SECRETKEY, (err, decoded) => {
        // Check for errors in token verification
        if (err)
            // If error, send forbidden status
            res.sendStatus(403)
        else {
            // If token is valid, log decoded token and respond with posts data
            console.log(decoded)
            res.json(posts)
        }
    })
})

// Start server listening on port 3000
app.listen(3000)
