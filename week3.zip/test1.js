const http = require('http')
const path = require('path')
const port = 3000

const server = http.createServer((req, res) => {

   if (req.url === '/') {

     res.write("shrutiben and N01579444");

     res.end();

  }

   if (req.url === '/api/courses') {

     res.write(JSON.stringify([1, 2, 3]));

     res.end();

  }

  
  if (req.url === '/random') {
    res.write(`${Math.random()}`);
    res.end();
}

});

server.listen(3000,() => {
    console.log(`Example app listening on port ${port}`)
  });
