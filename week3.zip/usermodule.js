
function calculateCircleArea(radius) {
    return Math.PI * radius ** 2;
}

function calculateRectangleArea(length, width) {
    return length * width;
}


module.exports = {
    calculateCircleArea,
    calculateRectangleArea
};
