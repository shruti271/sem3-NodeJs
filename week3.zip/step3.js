const express = require('express');
const app = express();

const usermodule = require('./usermodule');
    

const circleArea = usermodule.calculateCircleArea(5);
console.log('Area of circle with radius 5:', circleArea);

const rectangleArea = usermodule.calculateRectangleArea(4, 6);
console.log('Area of rectangle with length 4 and width 6:', rectangleArea);



app.get('/', (req, res) => {
    res.send("shrutiben and N01579444");
});


app.post('/post-route', (req, res) => {
    console.log('Received a POST request');
    res.send('POST request received');
});

app.get('/usr/:name', (req, res) => {
    const name = req.params.name;
    res.send(` ${name}`);
});

app.get('/query', (req, res) => {
    const name = req.query.name;
    res.send(`Hello ${name}`);
});


app.get('/api/courses', (req, res) => {
    res.json([1, 2, 3]);
});

app.get('/random', (req, res) => {
    res.send(`${Math.random()}`);
});

app.listen(3000, () => {
    console.log('Express app listening on port 3000');
});
