const express = require('express')
const path = require('path')
const app = express()
const port = 3000

app.get('/', (req, res) => {
  // res.sendFile(__dirname+'public'+'index.html')
  res.sendFile(path.join(__dirname, 'public', 'index.html'))
})

app.put('/user', (req, res) => {
  res.send('Got a PUT request at/user')
})

//dynamic route
app.get('/api/emps', (req, res) => {
  res.send([1, 2, 3])
})

app.get('/api/emps/:id', (req, res) => {
  res.send(req.params.id)
})

//activity 4
app.get('/api/posts/:month/:day', (req, res) => {
  console.log(req.params);
  // res.send(req.query);
  res.send(`${req.params.day} --- ${req.params.month}`);
})


app.get('/api/post/', (req, res) => {
  res.send(req.query);
});

app.get('/info', (req, res) => {
  res.send('Hello from info route')
})

app.get('/sum', (req, res) => {
  // res.writeHead(200, {'Content-Type' : 'application/json'});
  // array of numbers
  nums = [1, 2, 3, 4]
  sum = 0
  // Arrow function to add numbers together
  nums.forEach(num => {
    console.log(num)
    sum += num
  });

  console.log(sum)
  res.send(JSON.stringify(sum))
})

app.get('/node', (req, res) => {
  //response.writeHead(200, {'Content-Type' : 'application/json'});
  var one = 1
  var two = 2
  // Swap values
  var [one, two] = [two, one]
  console.log(`one: ${one}, two: ${two}`)
  res.send("Success")
})



app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})



//act1.js
