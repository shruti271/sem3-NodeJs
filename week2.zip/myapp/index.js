const express = require('express')
const app = express()
const port = 3000

// routes
app.get('/', (req, res) => {
  res.send('Hello World!')
})

// info
app.get('/info', (req, res) => {
    res.send('info call')
  })

// API
app.get('/api', (req, res) => {
    res.send('API call')
  })

  app.post('/add', (req, res) => {
    res.send('ADD call')
  })

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})

/*
cd my app
npm init
npm install express -save
code
*/