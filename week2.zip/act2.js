const http = require('http')
const fs = require('fs')

const server = http.createServer((req,res) => {

  if(req.url === '/sync'){
    let myData = fs.readFileSync('dataset.json');
    let contacts = JSON.parse(myData);
    console.log(contacts);
    //res.write('Sync call has been completed');
    res.writeHead(200, { 'Content-Type': 'text/html'});
    output=
    `<h3> List of contact: </h3>
        <ul>
            <li> firstName: ${contacts[0].first_name} </li>
            <li> lasttName: ${contacts[0].last_name} </li>
            <li> phone: ${contacts[0].phone} </li>
        </ul>`;
    res.write(output);
    res.end();
  }
  if(req.url === '/async'){
    fs.readFile('dataset.json', function (err,data) {
    if (err) {
        console.error(err);
        return;
    }
    //console.log(data.toString());
   
    res.write('Async call has been completed');
    res.end();
});
console.log("Program Ended");
   }
});
server.listen(3000);
console.log('Listening to on port 3000');