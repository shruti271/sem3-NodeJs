const { MongoClient, ObjectId } = require('mongodb'); // Importing the MongoClient from the mongodb package.
const express = require("express"); // Importing the express framework.
// const ObjectId = require('mongoclient');
const app = express(); // Creating an instance of the express application.
const port = 5000; // Setting the port number for the server.
// const { MongoClient, ObjectID } = require('mongodb');

// Connection URL for MongoDB
const url = 'mongodb://127.0.0.1:27017';

// Initialize the connection to the MongoDB server
const client = new MongoClient(url);

// Database Name
const dbName = 'myProject';

async function main() {
    // Use connect method to connect to the MongoDB server
    await client.connect(); // Asynchronously connecting to the MongoDB server.
    console.log('Connected successfully to server'); // Logging successful connection to the server.
    const db = client.db(dbName); // Accessing the specified database.
    const collection = db.collection('documents'); // Accessing the specified collection within the database.
    console.log('Connected'); // Logging successful connection to the database.
}

// Route handling for root endpoint "/"
app.get("/", (req, res) => {
    res.send("server is ready"); // Sending a response indicating that the server is ready.
});

// Route handling for inserting data into MongoDB collection
app.get("/insert", async (req, res) => {
    await client.connect(); // Asynchronously connecting to the MongoDB server.
    console.log('Connected successfully to server'); // Logging successful connection to the server.
    const db = client.db(dbName); // Accessing the specified database.
    const collection = db.collection('documents'); // Accessing the specified collection within the database.
    console.log('Connected'); // Logging successful connection to the database.
    // Insert Records
    const insertResult = await collection.insertOne({ b: 10 }); // Inserting a document into the collection.
    console.log('Inserted documents =>', insertResult); // Logging the result of the insertion.
    res.send("insert is ready"); // Sending a response indicating that the insertion operation is ready.
});

// Route handling for retrieving and displaying a single document
app.get("/show", async (req, res) => {
    client.connect(); // Connecting to the MongoDB server.
    findResult = await client.db(dbName).collection('documents').findOne({}); // Finding and retrieving a single document from the collection.
    console.log('Found documents =>', findResult); // Logging the retrieved document.
    res.send("show is ready"); // Sending a response indicating that the retrieval operation is ready.
});

// Route handling for displaying multiple documents
app.get("/display", async (req, res) => {
    await client.connect(); // Asynchronously connecting to the MongoDB server.
    const db = client.db(dbName); // Accessing the specified database.
    const collection = db.collection('documents'); // Accessing the specified collection within the database.
    const cursor = collection.find({ a: 3 }); // Finding documents where the field "a" equals 3.
    while (await cursor.hasNext()) { // Iterating over the documents using a cursor.
        console.log(await cursor.next()); // Logging each document.
    }
    res.send("display is ready"); // Sending a response indicating that the display operation is ready.
});


// Delete a document
app.get("/delete/:id", async (req, res) => {
    try {
        await client.connect();
        console.log('Connected successfully to server');
        const db = client.db(dbName);
        const collection = db.collection('documents');
        const deleted = await collection.deleteOne({ _id: new ObjectId(req.params.id) });
        console.log('Deleted document:', deleted);
        res.send("Document deleted successfully");
    } catch (error) {
        console.error('Error deleting document:', error);
        res.status(500).send("Error deleting document");
    }
});

// Update a document
app.get("/update/:id", async (req, res) => {
    try {
        await client.connect();
        console.log('Connected successfully to server');
        const db = client.db(dbName);
        const collection = db.collection('documents');
        const updated = await collection.updateOne(
            { _id: new ObjectId(req.params.id) },
            { $set: { b: 20 } } // Update 'b' field to 20
        );
        console.log('Updated document:', updated);
        res.send("Document updated successfully");
    } catch (error) {
        console.error('Error updating document:', error);
        res.status(500).send("Error updating document");
    }
});

// Starting the server to listen on the specified port
app.listen(port, () => {
    console.log(`server is running on port ${port}`); // Logging that the server is running and listening on the specified port.
});
